package com.example.projectrayna

data class LinkModel(
    val title: String,
    val image: Int,
    val url: String,
)
